# Student Course Portfolio

This static website is ready for GitHub Pages and includes a homepage, exercise index, project index, and wireframe.

## Customize before publishing

1. Replace every occurrence of `Your Name`, `YN`, and `Course Number` in the HTML files.
2. Update the exercise and project titles, descriptions, and tags.
3. Replace the placeholder files inside `exercises/` and `projects/` with completed coursework. Keep each assignment's main file named `index.html` so the existing links continue to work.
4. Open `index.html` locally to test the navigation.

## Publish with GitHub Pages

1. Add all files and folders to the root of your GitHub repository.
2. Commit and push the changes.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then click **Save**.
6. GitHub will display the public URL after deployment. It normally follows this format: `https://USERNAME.github.io/REPOSITORY-NAME/`.

Submit the public GitHub Pages URL in Canvas. The site’s **Wireframe** navigation link provides a viewable planning mock-up.
